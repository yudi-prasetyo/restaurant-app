const routes = {
  '/': 'main-menu',
  '/detail/:id': 'restaurant-detail',
  '/favorite': 'favorite-restaurants',
};

export default routes;
