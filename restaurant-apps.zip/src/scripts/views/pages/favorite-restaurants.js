import FavoriteRestaurantIdb from '../../data/favorite-restaurant-idb';

class FavoriteRestaurants extends HTMLElement {
  constructor() {
    super();
    this.shadowDOM = this.attachShadow({ mode: 'open' });
  }

  async connectedCallback() {
    this.shadowDOM.innerHTML = `
      <style>
        @import url('./styles/favorite-restaurants.css')
      </style>

      <section class="favorites">
          <h2 tabindex="0">Favorite Restaurants</h2>
          <restaurant-list></restaurant-list>
      </section>
    `;

    await this.afterRender();
  }

  async afterRender() {
    const restaurantList = this.shadowDOM.querySelector('restaurant-list');
    const restaurants = await FavoriteRestaurantIdb.getAllRestaurants();
    restaurantList.restaurants = restaurants;
  }
}

customElements.define('favorite-restaurants', FavoriteRestaurants);
