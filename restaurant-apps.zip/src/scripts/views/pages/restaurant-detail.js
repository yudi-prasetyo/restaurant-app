import RestaurantSource from '../../data/restaurant-source';
import UrlParser from '../../routes/url-parser';
import { createRestaurantDetailTemplate } from '../templates/template-creator';
import LikeButtonInitiator from '../../utils/like-button-initiator';
import './submit-review';

class RestaurantDetail extends HTMLElement {
  constructor() {
    super();
    this.shadowDOM = this.attachShadow({ mode: 'open' });
  }

  async connectedCallback() {
    this.shadowDOM.innerHTML = `
      <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css" crossorigin="anonymous">
  
      <style>
        @import url('./styles/restaurant-detail.css')
      </style>

      <div id="loader"></div>
      <div id="restaurantDetail" class="restaurant-detail"></div>
    `;

    setTimeout(async () => {
      await this.afterRender();
    }, 1000);
  }

  async afterRender() {
    const url = UrlParser.parseActiveUrlWithoutCombiner();
    try {
      const restaurant = await RestaurantSource.getRestaurantDetail(url.id);

      this.shadowDOM.getElementById('loader').style.display = 'none';
      const restaurantDetailContainer = this.shadowDOM.querySelector('#restaurantDetail');

      restaurantDetailContainer.innerHTML += createRestaurantDetailTemplate(restaurant);
      this.shadowDOM.innerHTML += '<submit-review></submit-review>';
      this.shadowDOM.innerHTML += '<div id="likeButtonContainer"></div>';

      LikeButtonInitiator.init({
        likeButtonContainer: this.shadowDOM.querySelector('#likeButtonContainer'),
        restaurant,
      });
    } catch (err) {
      const errorNode = document.createElement('p');
      errorNode.innerHTML = 'Tidak dapat menampilkan data';

      const restaurantDetailContainer = this.shadowDOM.querySelector('#restaurantDetail');

      restaurantDetailContainer.append(errorNode);
    }
  }
}

customElements.define('restaurant-detail', RestaurantDetail);
