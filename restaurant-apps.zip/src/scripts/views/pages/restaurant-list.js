import { createRestaurantItemTemplate } from '../templates/template-creator';

class RestaurantList extends HTMLElement {
  constructor() {
    super();
    this.shadowDOM = this.attachShadow({ mode: 'open' });
  }

  set restaurants(restaurants) {
    this._restaurants = restaurants;
    setTimeout(async () => {
      try {
        await this.afterRender();
      } catch (err) {
        const errorNode = document.createElement('p');
        errorNode.innerHTML = 'Tidak dapat menampilkan data';
        this.shadowDOM.append(errorNode);
      }
    }, 1000);
  }

  async connectedCallback() {
    this.shadowDOM.innerHTML = `
      <style>
        @import url('./styles/restaurant-list.css')
      </style>

      <div id="loader"></div>
    `;
  }

  async afterRender() {
    this.shadowDOM.getElementById('loader').style.display = 'none';

    if (this._restaurants.length) {
      this._restaurants.forEach((restaurant) => {
        this.shadowDOM.innerHTML += createRestaurantItemTemplate(restaurant);
      });
    } else {
      this.shadowDOM.innerHTML = '-';
    }
  }
}

customElements.define('restaurant-list', RestaurantList);
